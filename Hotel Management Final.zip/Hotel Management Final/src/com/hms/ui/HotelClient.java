package com.hms.ui;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.hms.bean.BookingBean;
import com.hms.bean.HotelBean;
//import com.hms.bean.RoomDetailsBean;
import com.hms.bean.RoomDetailsBean;
import com.hms.bean.UserBean;
import com.hms.exception.HotelException;
//import com.hms.service.AdminServiceImpl;
import com.hms.service.HotelServiceImpl;
import com.hms.service.IHotelService;

public class HotelClient {
	static Logger log=Logger.getRootLogger();
//-----------------VARIABLES--------------------------------------------------------	
	private static String user_id,hotelid;;
	private static String password;
	static Scanner scan=new Scanner(System.in);
	static IHotelService serv=null;
	static boolean loggedin=false;
	static HotelBean hb=null;
	static UserBean ub=null;
	static int i;
	static BookingBean bb=null;
	static boolean result;
//==========================PROGRAM MAIN=============================================	
	public static void main(String[] args) throws HotelException, SQLException {
		PropertyConfigurator.configure("resources/log4j.properties");
		System.out.println("====== WELCOME TO HOTEL BOOKINGS MANAGEMENT SYSTEM =====");
		System.out.println("1.Customer");
		System.out.println("2.Admin");
		System.out.println("Enter Your Option");
		//int option = scan.nextInt();
		int option=0;
		try {
		option = scan.nextInt();
		}
		catch (InputMismatchException e) {
			System.out.println("OOPS entered Invalid Option\nPlease Try Again");
		}
		
		switch (option) {
		case 1:
			hotelmain();
			break;
			
		case 2:
			adminMain();
			
			break;

		default:
			System.out.println("InValid Option");
			break;
		}
	}
	
	
	
//==============================hotelmain()===============================================	
//----------------------------- Main Menu Function----------------------------------------
	public static void hotelmain() throws HotelException{
		scan= new Scanner(System.in);
		//System.out.println("====== WELCOME TO HOTEL BOOKINGS MANAGEMENT SYSTEM =====");
		System.out.println("------------------------------------------------------");
		System.out.println("====== WELCOME TO CUSTOMER/HOTEL EMPLOYEE REGISTER/LOGIN FORM =======");
		System.out.println("1.Login or Register");
		System.out.println("2.Book room");
		System.out.println("3.Show booking status");
		System.out.println("4. Exit");
		int option=0;
		try {
		option=scan.nextInt();
		}
		catch (InputMismatchException e) {
			System.out.println("OOPS entered Invalid Option\nPlease Try Again");
		}
		switch(option){
			case 1:
					System.out.println("1. Login \n2. Register");
						int reg=scan.nextInt();
						switch(reg) {	
							case 1:
									int i=login();
									if(i==1) {
										afterlogin();
									}
									break;
							case 2:
	
								register();
								break;
		
							default:
								System.out.println("Option not found. please try again...");
				
						}
						break;
	
			case 2:
					System.out.println(" Available Hotels :");
					hotel();
					break;
				
			case 3:
				
					bookingStatus();
					break;
			case 4:
					exitFunct();
					break;
			default:
					System.out.println(" Invalid option.");
	
	}// switch
	}// main function

//-------------------------USER REGISTRATION-----------------------------------------------------
	private static void register () throws HotelException{
		boolean result=false;
		String role;
		String username;
		String mblnum;
		String ph;
		String add;
		String email;

		serv=new HotelServiceImpl();
		boolean useridfound;
		do {
			do {
				System.out.println("Enter userid ");
				user_id=scan.next();
				result=serv.validateid(user_id);
			}while(result==false);
		
		useridfound=serv.useridcheck(user_id);	
		
		if(useridfound==true) {
			System.out.println("user id already exists try other");
		}else {
			break;
		}
		}while(useridfound==true);
		
	
		do {

			System.out.println("Enter password ");

			password=scan.next();

			result=serv.validatepassword(password);

			}while(result==false);

			do {

			System.out.println("Enter your role");

			role = scan.next();

			result=serv.validaterole(role);

			}while(result==false);

			do {

			System.out.println("Enter username");

			username = scan.next();

			result=serv.validateusername(username);

			}while(result==false);

			do {

			System.out.println("Enter mobilenumber ");

			mblnum = scan.next();

			result=serv.validatemobilenumber(mblnum);

			}while(result==false);

			do {

			System.out.println("Enter alternate phone ");

			ph = scan.next();

			result=serv.validatealternatenumber(ph);

			}while(result==false);

			do {

			System.out.println("Enter address ");

			add = scan.next();

			result=serv.validateaddress(add);

			}while(result==false);

			do {

			System.out.println("Enter email ");

			email = scan.next();

			result=serv.validateemail(email);

			}while(result==false);
			//System.out.println("Enter email ");
			//email = scan.next();
			
			
		ub=new UserBean(user_id, password, role, username, mblnum, ph, add, email);
				 
			try{
				
				int status= serv.register(ub);
				if(status>0) {
						System.out.println("Registration successful. Please login to continue..");
						int i=login();
						if(i==1) {
							afterlogin();
						
						}
						
					}
				else {
						System.out.println("Error occured while registering...");
					}
				
			}catch(Exception e) {
				System.out.println(e.getMessage());
			 }
	
	}//register method
//---------------------------------USER LOGIN ------------------------------------------------------------
	private static int login() throws HotelException {
		int i=0;
		 Scanner scan=new Scanner(System.in);
		System.out.println("please enter your id ");
		user_id=scan.next();
	
		System.out.println("please enter your password ");
		password=scan.next();
	 
		serv= new HotelServiceImpl();
		 boolean status=serv.login(user_id,password);
		 if(status==true){
			 System.out.println("Logged In");
			 i=1; loggedin=true;
		 }
		 else{
				System.out.println(" Credentials not found, Please enter correct details or register again ");
				System.out.println(" Do you want go back to main menu?\n 1. Main Menu\n 2.Exit ");
				int choice=scan.nextInt();
				switch (choice) {
				case 1:
						hotelmain();
					break;
				case 2:
					exitFunct();
						break;
				default:
					break;
				}
			}
			 
			 return i;
		}//login method
		 
	 
	 public static void afterlogin()throws HotelException {
		 
		 System.out.println(" 1. Check Hotel Rooms\n 2. Check Booking Status ");	
		 	int option1=scan.nextInt();
		 	switch (option1) {
		 		case 1: 
		 			hotel();
		 			break;
		 		case 2: 		 			
		 			bookingStatus();
		 			break;
		 		default:
		 			System.out.println(" Enter Valid Option");
		 			break;
		}//switch		
	}
//--------------------------------GET ALL HOTELS------------------------------------
public static void hotel() throws HotelException {
	serv=new HotelServiceImpl();
	List<HotelBean> hotelList=null;
	try {		
		hotelList = serv.AllHotel();
	} catch (Exception e) {
		
	System.out.println(e.getMessage());
	}

	for(HotelBean hb:hotelList)
	{
		System.out.println(hb);	
	}	
	System.out.println("Choose an Option");
	System.out.println("1. Continue with Booking \n2. Exit\n");
	int choice=scan.nextInt();
	int exit=0;
	boolean hotelidfound=false;
	switch(choice) {
		case 1:
			do {
				System.out.println("Enter hotel Id");	
				hotelid=scan.next();
				hotelidfound=serv.hotelidcheck(hotelid);					
					if(hotelidfound==true) {
						availrooms(hotelid);
						break;
					}else {
						System.out.println("Hotel not found. Enter Hotel only from the above List");
					}
					}while(hotelidfound==false);								
			break;
		case 2:
			exitFunct();
			break;		
		default:
			System.out.println("Invalid Input");	
	}		
}
//----------------------- GET AVAILABLE ROOMS OF A HOTEL------------------------------------------------------
private static void availrooms(String hotelid) throws HotelException {
	
	serv=new HotelServiceImpl();
	List<RoomDetailsBean> rdbList=null;
	rdbList=serv.availrooms(hotelid);	
	for(RoomDetailsBean rdb:rdbList)
	{
		System.out.println(rdb);	
	}
	
	System.out.println("1. Continue with Booking \n2. Exit");
	int choice=scan.nextInt();
	
	switch(choice) {
	case 1:
		try {
			
			if(loggedin==false) {
				System.out.println(" You are not logged in.Please Login to Continue with booking..");
				int logincheck=login();
				if(logincheck==1) {
					booking();
				}
			}
			else if(loggedin==true)
				booking();
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		break;
	case 2:
		exitFunct();
		break;
	}
	
	
}

//-------------------------------------BOOKING----------------------------------------------------------------
private static void booking() throws HotelException {
	serv=new HotelServiceImpl();
	boolean roomidfound=false;
	 String todate=null;
	 String roomid;
	 String fromdate;
	 int noofdays;
	 int noofchildren=0;
	 int noofadults=0;
	 boolean result=false;
	 do {
	System.out.println("enter room_id");
	roomid=scan.next();
	roomidfound=serv.getroomid(roomid);
	
	if(roomidfound==true) {
		break;
	}else {
		System.out.println("room not found. Enter rooms only from the above List");
	}
	}while(roomidfound==false);

	 
	 do {
		 do {
			 System.out.println("No of days Required");
			 noofdays=scan.nextInt();
			 result=serv.validateNoOfDays(noofdays);
		 }while(result==false);
	
		 if(noofdays>30) {
			 System.out.println("Sorry, You cannot book a hotel more than 30 days..");
		 }
	 }while(noofdays>30);
	serv.noofdays(user_id,noofdays,hotelid);
	
	do {
		System.out.println("booked_from");
		fromdate=scan.next();
		result=serv.validateDate(fromdate);
	}while(result==false);

			do {
			System.out.println("booked_to");
			todate=scan.next();
			result=serv.validateDate(todate);
			}while(result==false);
	do {	
	System.out.println("No of adults");
	noofadults=scan.nextInt();
	 result=serv.validateNoOfDays(noofdays);
	 }while(result==false);
	
	do {
	System.out.println("No of Children");
	noofchildren=scan.nextInt();
	 result=serv.validateNoOfDays(noofdays);
	}while(result==false);
	
	BookingBean bb= new BookingBean(roomid, fromdate, todate, noofadults, noofchildren);
	int i=serv.booking(bb);
	
	if(i>0) {
		System.out.println("Your Booking for room "+ roomid + " for Hotel id "+hotelid +" is Successful" );
		System.out.println("Your Booking id is " +serv.getbookingid());
	}else
		System.out.println("An error occured while Booking");
}


//---------------------------BOOKING STATUS------------------------------------
public static void bookingStatus() throws HotelException {
	serv=new HotelServiceImpl();
	/*if(loggedin==false) {
		System.out.println("Please Login to continue...");
		i=login();
		}	
	if(loggedin==true) 
	{
		System.out.println("Your Bookings are : \n");
		List<BookingBean> bookinglist=null;
		if(bookinglist==null) {
			System.out.println("You have no active bookings.");
		}else {
			bookinglist=serv.getAllBookings(user_id);	
			for(BookingBean bl:bookinglist)
			{
				System.out.println(bl);	
			}
		}
	}
	System.out.println("1. Do You want to search for any Bookings? \n2.exit");
	int choice=scan.nextInt();
	switch (choice) {
	case 1:
		search();
		break;
	case 2: 
		exitFunct();
		break;
	default:
		
		break;
	}*/

	/*public static void search() throws HotelException {*/
		System.out.println("Enter your Booking id");
		String bookingId=scan.next();
		
		BookingBean bb=serv.bookingStatus(bookingId);
		if(bb!=null) {
		System.out.println(bb.toString());}
		else {
			System.out.println(" No bookings found for this id ");
		}
		
		System.out.println(" Do you want go back to main menu?\n 1. Main Menu\n 2.Exit ");
		int choice=scan.nextInt();
		switch (choice) {
		case 1:
				hotelmain();
			break;
		case 2:
			exitFunct();
				break;
		default:
			break;
		}
		
}
	//}	
	//}

//==============================Exit=================================================
public static void exitFunct() {
	
	System.out.println(" Thank You for Using the Application  ");
	System.exit(0);
	
}



public static void adminMain() throws HotelException, SQLException{
	
	
	/////////////////////////ADMIN
	
	HotelBean hBean=null;
	serv=new HotelServiceImpl();
	System.out.println("Admin Services");
	scan = new Scanner(System.in);
	do {
	System.out.println("Enter your User Name");
	String uName = scan.next();
	System.out.println("Enter your Password");
	String pass = scan.next();
	//serv = new AdminServiceImpl();
	result = serv.adminValidation(uName,pass);

	}while (result==false);
	log.info("successfully logged in");
	int option=0;
	do {
	System.out.println("1. View Hotels");
	System.out.println("2. View Rooms from Hotel");
	System.out.println("3. Add Hotels");
	System.out.println("4. Updating Hotels");
	System.out.println("5. View Bookings of specific Hotel");
	System.out.println("6. View Bookings by date");
	System.out.println("7. exit");
		System.out.println("Enter your option");
		try {
		option = scan.nextInt();
		}
		catch (InputMismatchException e) {
			System.out.println("OOPS entered Invalid Option\nPlease Try Again");
			log.info("entered invalid option \n please enter correctly");
		}
		scan.nextLine();
//	}while(option<=0);		
	switch(option) {
	//----------------viewing hotels-----------------------------
	case 1:			
		List<HotelBean> hList = null;			
		hList = getAllHotels();
		for (HotelBean hb:hList)
		System.out.println(hb);			
		break;			
	//----------------view rooms in particular hotel----------------
	case 2:
		boolean vRes=false;
		String hid;
		HotelBean hb = null;			
		do {
			System.out.println("Enter the Hotel Id");
			hid = scan.next();
			//AdminServiceImpl serv = new AdminServiceImpl();
			vRes=serv.hotelVal(hid);
		}while (vRes==false);			
		hb = getHotelById(hid);			
		if(hb!=null) {				
			List<RoomDetailsBean> rList1 = null;
			rList1 = getAllRooms(hid);
			if (rList1.isEmpty()) {
				System.out.println("Sorry No rooms available in the hotel id "+hid);	
				log.info("sorry no rooms availablein the hotel");
			}
			else {
				for (RoomDetailsBean obj : rList1) {
					System.out.println(obj);
				}
			}								
		}			
		else {
			System.out.println("Sorry No Hotel ID found");
			log.info("no hotel was found");
		}			
		break;			
	//------------adding hotels--------------------------------------------
	case 3:
		String hId;
		//AdminServiceImpl serv = new AdminServiceImpl();
		do {
			System.out.println("Enter the Hotel Id");
			hId = scan.nextLine();
			vRes=serv.hotelVal(hId);
		}while (vRes==false);
		HotelBean hb1 = null;
		hb1 = getHotelById(hId);
		if (hb1== null) {
			String city;
			do {
				System.out.println("Enter City");
				city = scan.nextLine();
				//AdminServiceImpl serv = new AdminServiceImpl();
				vRes=serv.cityVal(city);
				System.out.println("jfdnj");
			}while (vRes==false);
			String hName;
			do {
				System.out.println("Enter Hotel Name");
				hName = scan.nextLine();
				//AdminServiceImpl serv = new AdminServiceImpl();
				vRes=serv.nameVal(hName);
			}while (vRes==false);
			//System.out.println("Enter ");
			System.out.println("Enter Address");
			String address = scan.nextLine();
			System.out.println("Enter Description");
			String desc = scan.nextLine();
			String phone1;
			String phone2;
			do {
				System.out.println("Enter Phone Number 1: ");
				phone1 = scan.nextLine();
			
				vRes=serv.mnoVal(phone1);
			}while (vRes==false);
			
			do {
				System.out.println("Enter Phone Number 2: ");
				phone2 = scan.nextLine();
				//AdminServiceImpl serv = new AdminServiceImpl();
				vRes=serv.mnoVal(phone2);
			}while (vRes==false);
			//System.out.println("Enter Phone number 1");
			//String phone1 = scan.nextLine();
			//System.out.println("Enter Phone number 2");
			//String phone2 = scan.nextLine();
			System.out.println("Enter Rating");
			String rating = scan.nextLine();
			String email;
			do {
				System.out.println("Enter Email: ");
				email= scan.nextLine();
				vRes=serv.emailVal(email);
			}while (vRes==false);			
			//System.out.println("Enter Email");
			//String email = scan.nextLine();
			System.out.println("Enter Fax");
			String fax = scan.nextLine();
			String rate;
			do {
				System.out.println("Enter Avg Rate per Night: ");
				rate = scan.nextLine();
				//AdminServiceImpl serv = new AdminServiceImpl();
				vRes=serv.rateVal(rate);
			}while (vRes==false);			
			//System.out.println("Enter ");
			//int rate = scan.nextInt();			
			 hBean = new HotelBean(hId, city, hName, address, desc,rate, phone1, phone2, rating, email, fax);			
			int status = addHotel(hBean);			
			if (status>0) {
				System.out.println("1 Hotel inserted");
				log.info("1 data is inserted in to hotel");
			}
			else {
				System.out.println("Data Not inserted");
				log.info("failed to insert data");
			}																
		}
		else {
			System.out.println("Hotel Id Already Exists");
			log.info("oops hotel already exists");
		}			
		break;
	//--------------------updating  hotels------------------------------	
	case 4: 
		int opt=0;
		do {
		System.out.println("1. Update Hotel");
		System.out.println("2. Update Room in Hotel");
		System.out.println("3. exit");
		System.out.println("Enter your Option");
			try {
		 opt = scan.nextInt();
			}catch (InputMismatchException e) {
				System.out.println("OOPS entered Incorrect Option\nPlease Try Again");
				log.info("entered the invalid option");
			}
			scan.nextLine();	
	//	}while(opt<=0);
		switch (opt) {
		//--------------------updating hotel--------------------------------------
		case 1:
			HotelBean hBean4;
			String htid;
			do {					
				System.out.println("Enter the Hotel Id");
				htid = scan.next();
				hBean4 = getHotelById(htid);
				if (hBean4 == null) {
					System.out.println("Sorry Hotel Id is not available \n Please try again");
					log.info("Hotel id doesnot exist");
					//System.exit(0);
				}
				}while(hBean4==null);
             int opt1=0;
           do {
			System.out.println(hBean4);
			System.out.println("What do you want to Update???");
			System.out.println("2. CITY \n3.HOTEL_NAME \n4.ADDRESS "
					+ "\n5.DESCRIPTION \n6.AVG_RATE_PERNIGHT \n7.PHONE_NO1 \n8.PHONE_NO2"
					+ "\n9.RATING \n10.exit");
			System.out.println("Enter your option");
			try {
			opt1 = scan.nextInt();
			}
			catch (InputMismatchException e) {
				System.out.println("OOPS entered Invalid Option\nPlease Try Again");
			}
			switch(opt1){
			//----------------updating city------------------------------------
			case 2:
				System.out.println("Enter the City Name: ");
				String city1 = scan.next();
				int status1 = updateCity(city1, htid);
				if (status1>0) {
					//hBean.setCity(city1);
					System.out.println("city has been Updated Successfully");
					log.info("city has updated successfully");
				}
				else{
					System.out.println("city not updated");
					log.info("city not updated");
				}
				break;
			//-----------------------updatig name of hotel-------------------------	
			case 3:
				System.out.println("enter hotel name to update");
				String hname=scan.next();
				int status2 = updateName(hname, htid);
				if (status2>0) {
					System.out.println("hotel name has been Updated Successfully");
					log.info("hotelname has updated successfully");
				}
				else{
					System.out.println("hotel name not updated");
					log.info("hotel name is not updated");
				}
				break;
		//------------------------updating address of hotel--------------------------------		
			case 4:
				System.out.println("enter new address to update");
				String haddress=scan.next();
				int status3=updateAddress(haddress,htid);
				if (status3>0) {
					System.out.println("hotel address has been Updated Successfully");
					log.info("hotel address has been updated" );
				}
				else{
					System.out.println("hotel address not updated");
					log.info("hoteladdresss is not updated");
				}
				break;
		//-------------------------updating description of hotel------------------------------		
			case 5:
				System.out.println("enter description to update");
				String hdesc=scan.next();
				int status4=updateDesc(hdesc,htid);
				if (status4>0) {
					System.out.println("hotel description has been Updated Successfully");
					log.info("hotel description has been updated");
				}
				else{
					System.out.println("hotel descriptionnot updated");
					log.info("hotel description is not updated");
				}
				break;
		//----------------------------updating rate per night------------------------------------		
			case 6:
				System.out.println("enter average rate per night to update");
				String hrpn=scan.next();
				int status5=updateRpn(hrpn,htid);
				if (status5>0) {
					System.out.println("average rate per night has been Updated Successfully");
					log.info("average rate per night has been updated successsfully");
				}
				else{
					System.out.println("average rate per night not updated");
					log.info("average rate per night not updated");
					
				}
				break;
		//------------------------------updating phone number 1------------------------------------		
			case 7:
				System.out.println("enter phone number 1 to update");
				String hpn1=scan.next();
				int status6=updatepn1(hpn1,htid);
				if (status6>0) {
					System.out.println(" phone number 1 has been Updated Successfully");
					log.info("phone number 1 has been Updated Successfully");
				}
				else{
					System.out.println(" phone number 1 not updated");
					log.info(" phone number 1 not updated");
				}
				break;
		//---------------------------updating phone number 2-------------------------------------------		
			case 8:
				System.out.println("enter phone number 2 to update");
				String hpn2=scan.next();
				int status7=updatepn2(hpn2,htid);
				if (status7>0) {
					System.out.println(" phone number 2 has been Updated Successfully");
					log.info(" phone number 2 has been Updated Successfully");
				}
				else{
					System.out.println(" phone number 2 not updated");
					log.info("phone number 2 not updated");
				}
				break;
		//-------------------------updating rating of hotel-----------------------------------		
			case 9:
				System.out.println("enter new rating to update");
				String rating=scan.next();
				int status8=updateRating(rating,htid);
				if (status8>0) {
					System.out.println(" rating has been Updated Successfully");
					log.info(" rating has been Updated Successfully");
				}
				else{
					System.out.println(" rating not updated");
					log.info("rating not updated");
				}
				break;
		//-------------------------exit------------------------------------------		
			case 10:
				System.out.println("THANK YOU");
				System.exit(0);
				log.info("exit");
				default:
					System.out.println("you entered wrong option");
					log.info("invalid option");
			/*System.out.println("enter 1 to update another item");
			int do1=scan.nextInt();
			case4=serv.docase(do1);
			while(case4==false);*/
			}
		}while(opt1!=10);
           
           break;
        //--------------updating rooms in hotel--------------------------------   
		case 2:
			int opt2;
			System.out.println("enter hotel id ");
			String htid1=scan.next();
			do {
			System.out.println("1.add rooms");
			System.out.println("2.delete rooms");
			System.out.println("3. modify room info");
			System.out.println("4.exit");
			System.out.println("Enter your option");
			opt2 = scan.nextInt();
			switch(opt2){
	//---------------------adding rooms in particular hotel-------------------------------		
			case 1:
				System.out.println("enter room id");
				String rid=scan.next();
				System.out.println("enter room number");
				String rnum=scan.next();
				System.out.println("enter room type");
				String rtype=scan.next();
				System.out.println("rate per night");
				int rate1=scan.nextInt();
				System.out.println("availability");
				String avail=scan.next();
				RoomDetailsBean rbean=new RoomDetailsBean(htid1,rid, rnum, rtype,rate1, avail);
				int rstatus=radddetails(rbean);
				if(rstatus>0) {
				System.out.println("room added successfully");
				log.info("room added successfully");
				}
				else {
					System.out.println("try again");
					log.info("try again");
				}
				break;
	//-------------------------deleting rooms in particular hotel--------------------------------			
			case 2:
				int rstatus1=0;
				List<RoomDetailsBean> rbean1;
				rbean1 = getAllRooms(htid1);				
				if(rbean1.isEmpty()) {System.out.println("Sorry No rooms to DELETE");}
				else {
				do {
					String rid1;
					//AdminServiceImpl servv2 = new AdminServiceImpl();
					do {
						System.out.println("enter room id");/////////////
						rid1=scan.next();
						vRes=serv.roomVal(rid1);						
					}while(vRes==false);						
					rstatus1=deleteroom(rid1);
					if(rstatus1>0)
						System.out.println("room deleted successfully");
					//log.info("room deleted successfully");
					else {
						System.out.println("sorry......... room is not available");
						}					
				}while(rstatus1==0);
				}
				break;
	//-------------------------modifying rooms-------------------------------------------			
			case 3:
				String rid2=null;
				rbean1 = getAllRooms(htid1);
				//AdminServiceImpl servv2 = new AdminServiceImpl();
				if(rbean1.isEmpty()) {System.out.println("Sorry No rooms to Modify in this Hotel");}
				else {
					do {
						System.out.println("enter room id to modify room info");
						rid2=scan.next();
						vRes = serv.roomVal(rid2);						
					}while(vRes==false);					
					List<RoomDetailsBean> rBean5 = getRoomById(rid2);
					System.out.println(rBean5);
				if (rBean5.isEmpty()) {System.out.println("No such room id is available");}				
				else {
				System.out.println("What do you want to Update???");
				System.out.println("1.room number \n 2.room type \n 3.price \n 4.availability   ");
				System.out.println("Enter your option");
				int opt3 = scan.nextInt();
				switch(opt3){
				//---------------modifying room number--------------------------------------
					case 1:
					System.out.println("enter room number");
					String rnum1=scan.next();
					int rstatus2=updateRoomNumber(rnum1,rid2);
					if(rstatus2>0) {
						System.out.println("room number has been successfully updated");
						log.info("room number has been successfully updated");

					}
					else {
						System.out.println("try again");
						log.info("try again");
					}
					break;
				//-------------------modifying room type------------------------------------	
					case 2:
						System.out.println("enter type of room to modify");
						String rtype1=scan.next();
						int rstatus3=updateRoomType(rtype1,rid2);
						if(rstatus3>0) {
							System.out.println("room type has been successfully updated");
							log.info("room type has been successfully updated");
						}
						else {
							System.out.println("try again");
							log.info("try again");
						}
						break;
				//---------------------modifying price------------------------------------		
					case 3:
						System.out.println("enter new price to modify");
						int ppn=scan.nextInt();
						int rstatus4=updateRoomPrice(ppn,rid2);
						if(rstatus4>0) {
							System.out.println("price has been successfully updated");
							log.info("price has been successfully updated");

						}
						else {
							System.out.println("try again");
							log.info("try again");
						}
						break;
			//-------------------------modifying availability of room-------------------------------	
					case 4:
						System.out.println("enter new availability to modify");
						String avl=scan.next();
						int rstatus5=updateRoomAvailability(avl,rid2);
						if(rstatus5>0) {
							System.out.println("availability has been successfully updated");
							log.info("availability has been successfully updated");

						}
						else {
							System.out.println("try again");
							log.info("try again");
						}
						break;
				}
				}
				}
				case 4:
				System.out.println("****EXIT****");
				System.exit(0);
				default:
					System.out.println("entered option is incorrect");
					log.info("entered invalid option");
			}
			}while(opt2!=4);
			break;	
		case 3:
			System.out.println("THANK YOU");
			System.exit(0);
		default:
			System.out.println("please enter correct option");
			log.info("entered invalid option");
		}
	}while(opt!=3);
	//---------------viewing bookings of hotel-----------------------------	
	case 5:
		//AdminServiceImpl servv= new AdminServiceImpl();
		String hotelId;
		boolean vRes1=false;
		do {
			System.out.println("Enter hotel id");
			hotelId=scan.next();	
			vRes1 = serv.hotelVal(hotelId);
		}while(vRes1==false);
		
		hb = getHotelById(hotelId);
		if (hb!=null) {				
			List<BookingBean> b1=getHotelDetails(hotelId);
			if(b1.isEmpty()) {
				System.out.println("Sorry No bookings for this hotel");		
				log.info("no bookings found");
			}
			else {
				for (BookingBean b:b1)
					System.out.println(b1);
			}
		}
		else {
			System.out.println("Hotel Not Found");
			log.info("hotel not found");
		}			
		break;
//--------------viewing bookings by date-------------------------------		
	case 6:
		String bdate;
		//AdminServiceImpl serv1 = new AdminServiceImpl();
		do{
			System.out.println("enter From date");
			bdate=scan.next();
			vRes=serv.dateVal(bdate);

		}while(vRes==false);
		try {
			
			List<BookingBean> b2=getDetailsByDate(bdate);
			if (b2.isEmpty()) {
				System.out.println("NO Bookings Found for "+bdate);
				log.info("no bookings found");
			}
			else {
				for(BookingBean b: b2)
					System.out.println(b2);
			}
		}
		catch (Exception e) {
			System.out.println("Date is not valid");
			log.info("date is not valid");
			//System.out.println(e.getMessage());
		}
		break;
	case 7:
		System.out.println("THANK YOU!!!");
		System.exit(0);
		log.info("exit");
		break;
		default:
			System.out.println("entered option is incorrect");
			break;	
		}
}while(option!=7);
}
private static List<RoomDetailsBean> getRoomById(String rid2) throws SQLException {
	//serv = new AdminServiceImpl();
	return serv.getRoomById(rid2);
}
private static int updateRating(String rating, String htid) {
	//serv = new AdminServiceImpl();
	return serv.updateRating(rating,htid);
}		
private static int updatepn2(String hpn2, String htid) {
	//serv = new AdminServiceImpl();
	return serv.updatepn2(hpn2,htid);
}
private static int updateRoomAvailability(String avl, String rid2) {
	//serv = new AdminServiceImpl();
	return serv.updateRoomAvailability(avl,rid2);
}
private static int updateRoomPrice(int ppn, String rid2) {
	//serv = new AdminServiceImpl();
	return serv.updateRoomPrice(ppn,rid2);
}
private static int updateRoomType(String rtype1, String rid2) {
	//serv = new AdminServiceImpl();
	return serv.updateRoomType(rtype1,rid2);
}
	private static int updatepn1(String hpn1, String htid) {
	//serv = new AdminServiceImpl();
	return serv.updatepn1(hpn1,htid);
}
private static int updateRpn(String hrpn, String htid) {
	//serv = new AdminServiceImpl();
	return serv.updateRpn(hrpn,htid);
}
private static int updateDesc(String hdesc, String htid) {
	return serv.updateDesc(hdesc,htid);
}
private static int updateAddress(String haddress, String htid) {
	return serv.updateAddress(haddress,htid);
}
private static int updateName(String hname, String htid) {

	return serv.updateName(hname,htid);
}
private static int updateRoomNumber(String rnum, String rid2) throws SQLException {

	return serv.updateRoomNumber(rnum,rid2);
}
private static int deleteroom(String rid1) {

	return serv.deleteroom(rid1);
}
private static int radddetails(RoomDetailsBean rbean) throws SQLException {

	return serv.radddetails(rbean);
}
private static List<BookingBean> getDetailsByDate(String bdate) throws ParseException {
	return serv.getDetailsByDate(bdate);
}
private static List<BookingBean> getHotelDetails(String hotelId) throws SQLException {

	return serv.getHotelDetails(hotelId);
}
private static int updateCity(String city1, String htid) throws SQLException {
	return serv.updateCity(city1,htid);
}
private static HotelBean getHotelById(String htid) throws SQLException {

	return serv.getHotelById(htid);
}
private static int addHotel(HotelBean hBean) throws SQLException {

	return serv.addHotel(hBean);
}
private static List<RoomDetailsBean> getAllRooms(String hid) throws SQLException {
	return serv.getAllRooms(hid);
}
private static List<HotelBean> getAllHotels() throws HotelException, SQLException {
	return serv.getAllHotels();
}
}
