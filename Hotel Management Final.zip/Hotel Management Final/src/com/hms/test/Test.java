package com.hms.test;

import java.sql.Connection;

import java.util.List;

import org.junit.Assert;

import org.junit.Before;

import com.hms.bean.BookingBean;

import com.hms.bean.HotelBean;

import com.hms.bean.RoomDetailsBean;

import com.hms.bean.UserBean;

import com.hms.dao.HotelDaoImpl;

import com.hms.exception.HotelException;

import com.hms.util.DbUtil;

public class Test {

BookingBean bb=null;

HotelBean bo=null;

RoomDetailsBean ro=null;

boolean ub;

UserBean u=null;

HotelDaoImpl dao=null;

@Before

public void init() {

dao=new HotelDaoImpl();

}

//---------------------------------------------------Test for connection---------------------------------------------------------------------

@org.junit.Test

public void connectiondb() {

Connection conn=DbUtil.getDbConnection();

Assert.assertNotNull(conn);

}

//--------------------------------------------------Test for login-----------------------------------------------------------------------------

@org.junit.Test

public void logintest() throws HotelException{

ub=dao.login("122","chinnu");

Assert.assertNotNull(ub);

}

//-----------------------------------------------Test for Bookingstatus-------------------------------------------------------------------------

@org.junit.Test

public void Bookingstatustest() throws HotelException{

bb=dao.bookingStatus("1021");

Assert.assertNotNull(bb);

}

//----------------------------------------------Test for negative Bookingstatus-----------------------------------------------------------------

@org.junit.Test

public void Bookingstatustest2() throws HotelException{

bb=dao.bookingStatus("1895");

Assert.assertNotNull(bb);

}

//------------------------------------------------Test for retrieving HotelDetails---------------------------------------------------------------

@org.junit.Test

public void Hoteltest() throws HotelException{

List<HotelBean> list=dao.Allhotel();

Assert.assertNotNull(list);

}

//-----------------------------------------------Test for available rooms------------------------------------------------------------------------

@org.junit.Test

public void availroomtest() throws HotelException{

List<RoomDetailsBean> list=dao.availrooms("111");

Assert.assertNotNull(list);

}
}