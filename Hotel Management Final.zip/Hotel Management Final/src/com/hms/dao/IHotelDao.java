package com.hms.dao;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import com.hms.bean.BookingBean;
import com.hms.bean.HotelBean;
import com.hms.bean.RoomDetailsBean;
import com.hms.bean.RoomDetailsBean;
import com.hms.bean.UserBean;
import com.hms.exception.HotelException;

public interface IHotelDao {

public abstract	boolean login(String user_id, String password) throws HotelException;

public abstract int register(UserBean ub) throws HotelException;

public abstract BookingBean bookingStatus(String bookingId);

public abstract List<HotelBean> Allhotel();

public abstract List<RoomDetailsBean> availrooms(String hotelid) throws HotelException;

public abstract int booking(BookingBean bb);

public abstract void noofdays(String user_id,int noofdays,String hotelid) throws HotelException;

public abstract int getbookingid() throws HotelException;

public abstract boolean useridcheck(String user_id)throws HotelException;

public abstract boolean getroomid(String roomid);

public abstract boolean gethotelid(String hotelid);

/*public abstract List<BookingBean> getAllBookings(String user_id);*/

//********************************************************************************************



List<HotelBean> getAllHotels() throws HotelException ;

List<RoomDetailsBean> getAllRooms(String hid);

int addHotel(HotelBean hBean) ;

HotelBean getHotelById(String htid)  ;

int updateCity(String city1, String htid)  ;

List<BookingBean> getHotelDetails(String hotelId)  ;

List<BookingBean> getDetailsByDate(String bdate)  ;

int raddadetails(RoomDetailsBean rbean)  ;

int deleteroom(String rid1);

int updateRoomNumber(String rnum, String rid2)  ;

int updateName(String hname, String htid);

int updateAddress(String haddress, String htid);

int updateDesc(String hdesc, String htid);

int updateRpn(String hrpn, String htid);

int updatepn1(String hpn1, String htid);

int updateRoomType(String rtype1, String rid2);

int updateRoomPrice(int ppn, String rid2);

int updateRoomAvailability(String avl, String rid2);

int updateepn2(String hpn2, String htid);

int updateRating(String rating, String htid);

List<RoomDetailsBean> getRoomById(String rid2);

}
